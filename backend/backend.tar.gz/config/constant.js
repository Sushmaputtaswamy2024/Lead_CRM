module.exports = {
  ROLES: {
    ADMIN: "admin",
    BDA1: "bda1",
    BDA2: "bda2"
  },
  STATUSES: {
    NEW: "New",
    JUNK: "JUNK_REQUESTED"
  }
};
